<!DOCTYPE html>
<html lang="fr" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MnemoCloud - Connexion</title>
    <script>(function(){var t=localStorage.getItem('mc-theme')||'light';document.documentElement.setAttribute('data-bs-theme',t);})();</script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: #1e2a3a; }
        .login-card { width: 100%; max-width: 400px; }
        .brand { font-size: 1.5rem; font-weight: 800; color: #fff; text-align: center; margin-bottom: 1.5rem; }
        .brand small { display: block; font-size: .8rem; font-weight: 400; color: #adb5bd; }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="brand">
            <i class="bi bi-cloud-fill me-2" style="color:#0d6efd"></i>MnemoCloud
            <small>Administration</small>
        </div>
        <div class="card shadow-lg">
            <div class="card-body p-4">
                <h5 class="card-title mb-4">Connexion</h5>
                @if($errors->any())
                    <div class="alert alert-danger"><i class="bi bi-exclamation-triangle-fill me-1"></i> {{ $errors->first() }}</div>
                @endif
                <form method="POST" action="{{ route('login') }}">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label" for="email">Adresse e-mail</label>
                        <input type="email" id="email" name="email" class="form-control" value="{{ old('email') }}" required autofocus>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="password">Mot de passe</label>
                        <input type="password" id="password" name="password" class="form-control" required>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Se souvenir de moi</label>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Se connecter
                    </button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
