<!DOCTYPE html>
<html lang="fr" id="admin-html-root" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'MnemoCloud Administration') - MnemoCloud</title>
    <script>
        (function() {
            var t = localStorage.getItem('mc-theme') || 'light';
            document.documentElement.setAttribute('data-bs-theme', t);
        })();
    </script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root { --sidebar-width: 260px; }
        [data-bs-theme="light"] {
            --sidebar-bg: #1e2a3a;
            --sidebar-color: #adb5bd;
            --sidebar-active: #fff;
            --sidebar-hover-bg: rgba(255,255,255,.05);
            --sidebar-header-color: #6c757d;
            --topbar-bg: #fff;
            --topbar-border: #dee2e6;
        }
        [data-bs-theme="dark"] {
            --sidebar-bg: #161d27;
            --sidebar-color: #adb5bd;
            --sidebar-active: #fff;
            --sidebar-hover-bg: rgba(255,255,255,.05);
            --sidebar-header-color: #6c757d;
            --topbar-bg: #1a2234;
            --topbar-border: #2d3748;
        }
        body { overflow-x: hidden; }
        .wrapper { display: flex; min-height: 100vh; }
        /* Sidebar */
        .sidebar {
            width: var(--sidebar-width);
            min-width: var(--sidebar-width);
            background: var(--sidebar-bg);
            display: flex;
            flex-direction: column;
            position: sticky;
            top: 0;
            height: 100vh;
            overflow-y: auto;
            transition: margin-left .3s ease;
            z-index: 100;
        }
        .sidebar-brand {
            padding: 1.25rem 1rem;
            display: block;
            text-decoration: none;
            color: #fff;
            font-size: 1.1rem;
            font-weight: 800;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }
        .sidebar-brand small { display: block; font-weight: 400; font-size: .75rem; color: var(--sidebar-color); }
        .sidebar-nav { list-style: none; padding: .5rem 0; margin: 0; }
        .sidebar-header {
            padding: .75rem 1rem .25rem;
            font-size: .7rem;
            font-weight: 700;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--sidebar-header-color);
        }
        .sidebar-link {
            display: flex;
            align-items: center;
            gap: .6rem;
            padding: .5rem 1rem;
            color: var(--sidebar-color);
            text-decoration: none;
            font-size: .875rem;
            border-radius: 4px;
            margin: 1px .5rem;
            transition: background .15s, color .15s;
        }
        .sidebar-link:hover { background: var(--sidebar-hover-bg); color: var(--sidebar-active); }
        .sidebar-item.active > .sidebar-link { color: var(--sidebar-active); background: rgba(255,255,255,.07); }
        .sidebar-link i { font-size: 1rem; min-width: 1.1rem; }
        /* Main */
        .main { flex: 1; min-width: 0; display: flex; flex-direction: column; }
        /* Topbar */
        .topbar {
            background: var(--topbar-bg);
            border-bottom: 1px solid var(--topbar-border);
            padding: .5rem 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: sticky;
            top: 0;
            z-index: 99;
        }
        .content { padding: 1.5rem; flex: 1; }
        .footer { padding: .75rem 1.5rem; font-size: .8rem; text-align: center; color: #6c757d; border-top: 1px solid var(--topbar-border); }
        /* Mobile */
        @media (max-width: 991.98px) {
            .sidebar { position: fixed; top: 0; left: 0; bottom: 0; margin-left: calc(-1 * var(--sidebar-width)); }
            .sidebar.open { margin-left: 0; }
            .main { margin-left: 0 !important; }
        }
        #sidebar-overlay { display: none; position: fixed; inset: 0; background: rgba(0,0,0,.5); z-index: 99; }
    </style>
    @stack('head')
</head>
<body>
<div id="sidebar-overlay" onclick="closeSidebar()"></div>
<div class="wrapper">
    <nav class="sidebar" id="sidebar">
        <a class="sidebar-brand" href="{{ route('admin.dashboard') }}">
            <span>MnemoCloud</span>
            <small>Administration</small>
        </a>
        <ul class="sidebar-nav">
            <li class="sidebar-item {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                <a class="sidebar-link" href="{{ route('admin.dashboard') }}"><i class="bi bi-speedometer2"></i> Tableau de bord</a>
            </li>
            <li class="sidebar-header">Distribution</li>
            <li class="sidebar-item {{ request()->routeIs('admin.plugins.*') ? 'active' : '' }}">
                <a class="sidebar-link" href="{{ route('admin.plugins.index') }}"><i class="bi bi-puzzle"></i> Plugins</a>
            </li>
            <li class="sidebar-item {{ request()->routeIs('admin.mnemo-versions.*') ? 'active' : '' }}">
                <a class="sidebar-link" href="{{ route('admin.mnemo-versions.index') }}"><i class="bi bi-cloud-arrow-up"></i> Versions Mnemo</a>
            </li>
            <li class="sidebar-header">Clients</li>
            <li class="sidebar-item {{ request()->routeIs('admin.sites.*') ? 'active' : '' }}">
                <a class="sidebar-link" href="{{ route('admin.sites.index') }}"><i class="bi bi-hdd-network"></i> Sites</a>
            </li>
            <li class="sidebar-header">Monitoring</li>
            <li class="sidebar-item {{ request()->routeIs('admin.api-logs.*') ? 'active' : '' }}">
                <a class="sidebar-link" href="{{ route('admin.api-logs.index') }}"><i class="bi bi-journal-text"></i> Logs API</a>
            </li>
        </ul>
    </nav>

    <div class="main">
        <div class="topbar">
            <button class="btn btn-sm btn-outline-secondary d-lg-none" onclick="toggleSidebar()">
                <i class="bi bi-list"></i>
            </button>
            <div></div>
            <div class="d-flex align-items-center gap-2">
                <button id="theme-btn" class="btn btn-sm btn-outline-secondary" onclick="toggleTheme()" title="Thème">
                    <i class="bi bi-moon-fill"></i>
                </button>
                <div class="dropdown">
                    <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle"></i> {{ Auth::user()->name ?? Auth::user()->email ?? 'Admin' }}
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="bi bi-box-arrow-right me-1"></i> Déconnexion
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

        <main class="content">
            <h1 class="h3 mb-3">@yield('title', 'Administration')</h1>

            @if(session('success'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <i class="bi bi-check-circle-fill me-1"></i> {{ session('success') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif
            @if(session('error'))
                <div class="alert alert-danger alert-dismissible" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-1"></i> {{ session('error') }}
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            @endif

            @yield('content')
        </main>

        <footer class="footer">MnemoCloud &copy; {{ date('Y') }}</footer>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleSidebar() {
    var s = document.getElementById('sidebar');
    var o = document.getElementById('sidebar-overlay');
    s.classList.toggle('open');
    o.style.display = s.classList.contains('open') ? 'block' : 'none';
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebar-overlay').style.display = 'none';
}
function toggleTheme() {
    var root = document.getElementById('admin-html-root');
    var t = root.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-bs-theme', t);
    localStorage.setItem('mc-theme', t);
    document.getElementById('theme-btn').innerHTML = t === 'dark' ? '<i class="bi bi-sun-fill"></i>' : '<i class="bi bi-moon-fill"></i>';
}
(function() {
    var t = localStorage.getItem('mc-theme') || 'light';
    document.getElementById('theme-btn').innerHTML = t === 'dark' ? '<i class="bi bi-sun-fill"></i>' : '<i class="bi bi-moon-fill"></i>';
})();
</script>
@stack('scripts')
</body>
</html>
