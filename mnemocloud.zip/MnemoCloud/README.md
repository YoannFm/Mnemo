# MnemoCloud

MnemoCloud is a private SaaS platform for managing plugin distribution and update delivery for Mnemo instances. It provides a REST API that Mnemo instances use to discover, license-check, and download plugins and core updates, plus an admin panel for managing everything.

## Features

- **Plugin management** — upload versioned plugin ZIPs, manage free/paid licensing
- **Mnemo core updates** — distribute versioned ZIPs with optional forced-update flag
- **Site registry** — register Mnemo instances with unique site keys and plan tracking
- **License management** — control which sites can access paid plugins
- **API logging** — every API call is logged with site, endpoint, IP, and response code
- **Admin panel** — Bootstrap 5 web UI for all management tasks
- **REST API** — authenticated via `X-Site-Key` header or `site_key` query param

## Requirements

- PHP 8.3+
- MySQL 8+
- Composer

## Setup

```bash
# Install dependencies
composer install

# Copy env file
cp .env.example .env

# Generate app key
php artisan key:generate

# Configure database in .env, then migrate
php artisan migrate

# Seed default admin user (admin@mnemocloud.local / changeme123)
php artisan db:seed

# Or create a custom admin
php artisan mnemocloud:create-admin you@example.com yourpassword

# Create storage directories
mkdir -p storage/app/plugins storage/app/mnemo_versions
```

## Docker / Pterodactyl

Use the provided `Dockerfile` to build a container image. The `egg-mnemocloud.json` file is a Pterodactyl egg for hosting on a panel.

```bash
docker build -t mnemocloud .
docker run -p 80:80 --env-file .env mnemocloud
```

## API Reference

All API endpoints are prefixed with `/api/v1`. Authenticated endpoints require `X-Site-Key: <key>` header or `?site_key=<key>` query param.

### POST /api/v1/ping
Verify/update a site registration. No auth required.

**Body:** `{ site_key, domain, mnemo_version }`

**Response:** `{ status: "ok", site: { name, plan }, message }`

### GET /api/v1/plugins
List all active plugins with latest stable version info and license status.

### GET /api/v1/plugins/{slug}
Get plugin details and all versions. Returns 403 if paid plugin without license.

### GET /api/v1/plugins/{slug}/download/{version}
Download a plugin ZIP. Returns 403 if paid without license. Increments download counter.

### GET /api/v1/updates/check?current_version=X.Y.Z
Check for available Mnemo core updates.

**Response:** `{ has_update: bool, latest: { version, changelog, is_forced, download_url } | null }`

### GET /api/v1/updates/download/{version}
Download a Mnemo core version ZIP. Increments download counter.

## Storage

Files are stored on two configurable disks:

| Disk | Default | Env var |
|------|---------|---------|
| `plugins` | `storage/app/plugins` | `FILESYSTEM_DISK_PLUGINS=local\|s3` |
| `mnemo_versions` | `storage/app/mnemo_versions` | `FILESYSTEM_DISK_MNEMO_VERSIONS=local\|s3` |

Set to `s3` and configure `AWS_*` vars to use S3 or Cloudflare R2.

## License

Copyright (c) 2026 MnemoCloud. All rights reserved. See [LICENSE](LICENSE).
