<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MnemoVersion extends Model
{
    use HasFactory;

    protected $fillable = [
        'version',
        'changelog',
        'file_path',
        'file_size',
        'is_stable',
        'is_forced',
        'downloads',
        'released_at',
    ];

    protected $casts = [
        'is_stable' => 'boolean',
        'is_forced' => 'boolean',
        'downloads' => 'integer',
        'file_size' => 'integer',
        'released_at' => 'datetime',
    ];

    public function scopeStable(Builder $query): Builder
    {
        return $query->where('is_stable', true);
    }

    public function scopeForced(Builder $query): Builder
    {
        return $query->where('is_forced', true);
    }
}
