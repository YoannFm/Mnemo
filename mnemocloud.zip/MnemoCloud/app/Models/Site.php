<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Site extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'domain',
        'site_key',
        'plan',
        'is_active',
        'last_ping_at',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'last_ping_at' => 'datetime',
    ];

    public function licenses(): HasMany
    {
        return $this->hasMany(License::class);
    }

    public function apiLogs(): HasMany
    {
        return $this->hasMany(ApiLog::class);
    }

    public static function generateKey(): string
    {
        return bin2hex(random_bytes(32)); // 64 hex chars
    }

    public function hasLicenseFor(int $pluginId): bool
    {
        return $this->licenses()
            ->where('plugin_id', $pluginId)
            ->where(function ($q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>', now());
            })
            ->exists();
    }
}
