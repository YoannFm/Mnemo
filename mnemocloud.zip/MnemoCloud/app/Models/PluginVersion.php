<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PluginVersion extends Model
{
    use HasFactory;

    protected $fillable = [
        'plugin_id',
        'version',
        'changelog',
        'file_path',
        'file_size',
        'is_stable',
        'downloads',
    ];

    protected $casts = [
        'is_stable' => 'boolean',
        'downloads' => 'integer',
        'file_size' => 'integer',
    ];

    public function plugin(): BelongsTo
    {
        return $this->belongsTo(Plugin::class);
    }
}
