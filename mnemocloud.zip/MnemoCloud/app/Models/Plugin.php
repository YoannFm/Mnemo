<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Plugin extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'description',
        'author',
        'is_free',
        'price',
        'is_active',
    ];

    protected $casts = [
        'is_free' => 'boolean',
        'is_active' => 'boolean',
        'price' => 'decimal:2',
    ];

    public function pluginVersions(): HasMany
    {
        return $this->hasMany(PluginVersion::class);
    }

    public function licenses(): HasMany
    {
        return $this->hasMany(License::class);
    }

    public function latestStableVersion(): ?PluginVersion
    {
        return $this->pluginVersions()
            ->where('is_stable', true)
            ->latest()
            ->first();
    }
}
