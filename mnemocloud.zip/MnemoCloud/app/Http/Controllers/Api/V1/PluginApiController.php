<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Plugin;
use App\Models\PluginVersion;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;

class PluginApiController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $site = $request->attributes->get('site');

        $plugins = Plugin::where('is_active', true)
            ->with(['pluginVersions' => fn($q) => $q->where('is_stable', true)->latest()->limit(1)])
            ->get()
            ->map(function (Plugin $plugin) use ($site) {
                $latest = $plugin->latestStableVersion();
                $hasLicense = $plugin->is_free || $site->hasLicenseFor($plugin->id);

                return [
                    'id'          => $plugin->id,
                    'name'        => $plugin->name,
                    'slug'        => $plugin->slug,
                    'description' => $plugin->description,
                    'author'      => $plugin->author,
                    'is_free'     => $plugin->is_free,
                    'price'       => $plugin->price,
                    'has_license' => $hasLicense,
                    'latest_version' => $latest ? [
                        'version'    => $latest->version,
                        'is_stable'  => $latest->is_stable,
                        'download_url' => $hasLicense
                            ? route('api.plugins.download', ['slug' => $plugin->slug, 'version' => $latest->version])
                            : null,
                    ] : null,
                ];
            });

        return response()->json(['plugins' => $plugins]);
    }

    public function show(Request $request, string $slug): JsonResponse
    {
        $site = $request->attributes->get('site');

        $plugin = Plugin::where('slug', $slug)->where('is_active', true)->firstOrFail();

        $hasLicense = $plugin->is_free || $site->hasLicenseFor($plugin->id);

        if (! $hasLicense) {
            return response()->json(['error' => 'You do not have a license for this plugin.'], 403);
        }

        $versions = $plugin->pluginVersions()->latest()->get()->map(fn(PluginVersion $v) => [
            'version'      => $v->version,
            'changelog'    => $v->changelog,
            'is_stable'    => $v->is_stable,
            'file_size'    => $v->file_size,
            'downloads'    => $v->downloads,
            'download_url' => route('api.plugins.download', ['slug' => $slug, 'version' => $v->version]),
            'created_at'   => $v->created_at?->toIso8601String(),
        ]);

        return response()->json([
            'plugin' => [
                'id'          => $plugin->id,
                'name'        => $plugin->name,
                'slug'        => $plugin->slug,
                'description' => $plugin->description,
                'author'      => $plugin->author,
                'is_free'     => $plugin->is_free,
                'price'       => $plugin->price,
            ],
            'versions' => $versions,
        ]);
    }

    public function download(Request $request, string $slug, string $version): Response|JsonResponse
    {
        $site = $request->attributes->get('site');

        $plugin = Plugin::where('slug', $slug)->where('is_active', true)->firstOrFail();

        $hasLicense = $plugin->is_free || $site->hasLicenseFor($plugin->id);

        if (! $hasLicense) {
            return response()->json(['error' => 'You do not have a license for this plugin.'], 403);
        }

        $pluginVersion = PluginVersion::where('plugin_id', $plugin->id)
            ->where('version', $version)
            ->firstOrFail();

        if (! Storage::disk('plugins')->exists($pluginVersion->file_path)) {
            return response()->json(['error' => 'File not found.'], 404);
        }

        $pluginVersion->increment('downloads');

        $filename = $plugin->slug . '-' . $version . '.zip';
        return response()->download(
            Storage::disk('plugins')->path($pluginVersion->file_path),
            $filename
        );
    }
}
