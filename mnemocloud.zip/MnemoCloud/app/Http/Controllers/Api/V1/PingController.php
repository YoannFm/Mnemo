<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\Site;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PingController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $siteKey = $request->input('site_key');
        $domain = $request->input('domain');

        if (! $siteKey) {
            ApiLog::create([
                'site_id' => null,
                'endpoint' => $request->path(),
                'method' => $request->method(),
                'ip' => $request->ip(),
                'response_code' => 422,
                'created_at' => now(),
            ]);
            return response()->json(['error' => 'site_key is required'], 422);
        }

        $site = Site::where('site_key', $siteKey)->first();

        if (! $site) {
            ApiLog::create([
                'site_id' => null,
                'endpoint' => $request->path(),
                'method' => $request->method(),
                'ip' => $request->ip(),
                'response_code' => 404,
                'created_at' => now(),
            ]);
            return response()->json(['error' => 'Site not found. Register your site in MnemoCloud admin.'], 404);
        }

        if (! $site->is_active) {
            ApiLog::create([
                'site_id' => $site->id,
                'endpoint' => $request->path(),
                'method' => $request->method(),
                'ip' => $request->ip(),
                'response_code' => 403,
                'created_at' => now(),
            ]);
            return response()->json(['error' => 'Site is inactive.'], 403);
        }

        $site->update([
            'last_ping_at' => now(),
            'domain' => $domain ?? $site->domain,
        ]);

        ApiLog::create([
            'site_id' => $site->id,
            'endpoint' => $request->path(),
            'method' => $request->method(),
            'ip' => $request->ip(),
            'response_code' => 200,
            'created_at' => now(),
        ]);

        return response()->json([
            'status' => 'ok',
            'site' => [
                'name' => $site->name,
                'plan' => $site->plan,
            ],
            'message' => 'Ping received. Connection established.',
        ]);
    }
}
