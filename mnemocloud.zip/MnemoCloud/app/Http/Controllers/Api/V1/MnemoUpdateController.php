<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\MnemoVersion;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;

class MnemoUpdateController extends Controller
{
    public function check(Request $request): JsonResponse
    {
        $currentVersion = $request->query('current_version', '0.0.0');

        $latest = MnemoVersion::stable()->latest('released_at')->first();

        if (! $latest) {
            return response()->json(['has_update' => false, 'latest' => null]);
        }

        $hasUpdate = version_compare($latest->version, $currentVersion, '>');

        // Check if there's a forced update even if not "newer" by semver
        $forced = MnemoVersion::forced()
            ->where('version', '!=', $currentVersion)
            ->latest('released_at')
            ->first();

        if ($forced && ! $hasUpdate) {
            $hasUpdate = true;
            $latest = $forced;
        }

        return response()->json([
            'has_update' => $hasUpdate,
            'latest' => $hasUpdate ? [
                'version'      => $latest->version,
                'changelog'    => $latest->changelog,
                'is_forced'    => $latest->is_forced,
                'file_size'    => $latest->file_size,
                'download_url' => route('api.updates.download', ['version' => $latest->version]),
                'released_at'  => $latest->released_at?->toIso8601String(),
            ] : null,
        ]);
    }

    public function download(Request $request, string $version): Response|JsonResponse
    {
        $mnemoVersion = MnemoVersion::where('version', $version)->firstOrFail();

        if (! Storage::disk('mnemo_versions')->exists($mnemoVersion->file_path)) {
            return response()->json(['error' => 'File not found.'], 404);
        }

        $mnemoVersion->increment('downloads');

        $filename = 'mnemo-' . $version . '.zip';
        return response()->download(
            Storage::disk('mnemo_versions')->path($mnemoVersion->file_path),
            $filename
        );
    }
}
