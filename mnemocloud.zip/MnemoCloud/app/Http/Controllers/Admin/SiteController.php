<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Site;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class SiteController extends Controller
{
    public function index(): View
    {
        $sites = Site::latest()->paginate(20);
        return view('admin.sites.index', compact('sites'));
    }

    public function create(): View
    {
        return view('admin.sites.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'   => 'required|string|max:255',
            'domain' => 'required|string|max:255',
            'plan'   => 'required|in:free,paid',
        ]);

        $data['site_key'] = Site::generateKey();
        $data['is_active'] = true;

        $site = Site::create($data);

        return redirect()->route('admin.sites.show', $site)
            ->with('success', 'Site created successfully. Key: ' . $site->site_key);
    }

    public function show(Site $site): View
    {
        $site->load('licenses.plugin');
        return view('admin.sites.show', compact('site'));
    }

    public function edit(Site $site): View
    {
        return view('admin.sites.edit', compact('site'));
    }

    public function update(Request $request, Site $site): RedirectResponse
    {
        $data = $request->validate([
            'name'      => 'required|string|max:255',
            'domain'    => 'required|string|max:255',
            'plan'      => 'required|in:free,paid',
            'is_active' => 'sometimes|boolean',
        ]);

        $data['is_active'] = $request->boolean('is_active');

        $site->update($data);

        return redirect()->route('admin.sites.show', $site)
            ->with('success', 'Site updated successfully.');
    }

    public function destroy(Site $site): RedirectResponse
    {
        $site->delete();
        return redirect()->route('admin.sites.index')
            ->with('success', 'Site deleted.');
    }
}
