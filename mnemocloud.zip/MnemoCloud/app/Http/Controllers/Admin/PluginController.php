<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plugin;
use App\Models\PluginVersion;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class PluginController extends Controller
{
    public function index(): View
    {
        $plugins = Plugin::withCount('pluginVersions')->latest()->paginate(20);
        return view('admin.plugins.index', compact('plugins'));
    }

    public function create(): View
    {
        return view('admin.plugins.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'slug'        => 'required|string|max:255|unique:plugins,slug',
            'description' => 'nullable|string',
            'author'      => 'nullable|string|max:255',
            'is_free'     => 'sometimes|boolean',
            'price'       => 'required|numeric|min:0',
            'is_active'   => 'sometimes|boolean',
        ]);

        $data['is_free'] = $request->boolean('is_free');
        $data['is_active'] = $request->boolean('is_active');

        Plugin::create($data);

        return redirect()->route('admin.plugins.index')
            ->with('success', 'Plugin created successfully.');
    }

    public function show(Plugin $plugin): View
    {
        $plugin->load('pluginVersions');
        return view('admin.plugins.show', compact('plugin'));
    }

    public function edit(Plugin $plugin): View
    {
        return view('admin.plugins.edit', compact('plugin'));
    }

    public function update(Request $request, Plugin $plugin): RedirectResponse
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'slug'        => 'required|string|max:255|unique:plugins,slug,' . $plugin->id,
            'description' => 'nullable|string',
            'author'      => 'nullable|string|max:255',
            'is_free'     => 'sometimes|boolean',
            'price'       => 'required|numeric|min:0',
            'is_active'   => 'sometimes|boolean',
        ]);

        $data['is_free'] = $request->boolean('is_free');
        $data['is_active'] = $request->boolean('is_active');

        $plugin->update($data);

        return redirect()->route('admin.plugins.show', $plugin)
            ->with('success', 'Plugin updated successfully.');
    }

    public function destroy(Plugin $plugin): RedirectResponse
    {
        $plugin->delete();
        return redirect()->route('admin.plugins.index')
            ->with('success', 'Plugin deleted.');
    }

    public function storeVersion(Request $request, Plugin $plugin): RedirectResponse
    {
        $data = $request->validate([
            'version'   => 'required|string|max:50',
            'changelog' => 'nullable|string',
            'file'      => 'required|file|mimes:zip',
            'is_stable' => 'sometimes|boolean',
        ]);

        $file = $request->file('file');
        $path = $file->storeAs(
            $plugin->slug,
            $plugin->slug . '-' . $data['version'] . '.zip',
            'plugins'
        );

        PluginVersion::create([
            'plugin_id'  => $plugin->id,
            'version'    => $data['version'],
            'changelog'  => $data['changelog'] ?? null,
            'file_path'  => $path,
            'file_size'  => $file->getSize(),
            'is_stable'  => $request->boolean('is_stable', true),
            'downloads'  => 0,
        ]);

        return redirect()->route('admin.plugins.show', $plugin)
            ->with('success', 'Version uploaded successfully.');
    }

    public function destroyVersion(Plugin $plugin, PluginVersion $version): RedirectResponse
    {
        Storage::disk('plugins')->delete($version->file_path);
        $version->delete();

        return redirect()->route('admin.plugins.show', $plugin)
            ->with('success', 'Version deleted.');
    }
}
