<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\Site;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ApiLogController extends Controller
{
    public function index(Request $request): View
    {
        $query = ApiLog::with('site')->orderByDesc('created_at');

        if ($request->filled('site_id')) {
            $query->where('site_id', $request->site_id);
        }

        if ($request->filled('response_code')) {
            $query->where('response_code', $request->response_code);
        }

        $logs = $query->paginate(50)->withQueryString();
        $sites = Site::orderBy('name')->get();

        return view('admin.api-logs.index', compact('logs', 'sites'));
    }
}
