<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ApiLog;
use App\Models\MnemoVersion;
use App\Models\Plugin;
use App\Models\Site;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function index(): View
    {
        $stats = [
            'total_sites'    => Site::count(),
            'total_plugins'  => Plugin::count(),
            'total_versions' => MnemoVersion::count(),
            'api_calls_today' => ApiLog::whereDate('created_at', today())->count(),
        ];

        return view('admin.dashboard', compact('stats'));
    }
}
