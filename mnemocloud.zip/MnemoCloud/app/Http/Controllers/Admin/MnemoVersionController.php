<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MnemoVersion;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class MnemoVersionController extends Controller
{
    public function index(): View
    {
        $versions = MnemoVersion::latest('released_at')->paginate(20);
        return view('admin.mnemo-versions.index', compact('versions'));
    }

    public function create(): View
    {
        return view('admin.mnemo-versions.create');
    }

    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'version'     => 'required|string|max:50|unique:mnemo_versions,version',
            'changelog'   => 'nullable|string',
            'file'        => 'required|file|mimes:zip',
            'is_stable'   => 'sometimes|boolean',
            'is_forced'   => 'sometimes|boolean',
            'released_at' => 'nullable|date',
        ]);

        $file = $request->file('file');
        $path = $file->storeAs(
            '',
            'mnemo-' . $data['version'] . '.zip',
            'mnemo_versions'
        );

        MnemoVersion::create([
            'version'     => $data['version'],
            'changelog'   => $data['changelog'] ?? null,
            'file_path'   => $path,
            'file_size'   => $file->getSize(),
            'is_stable'   => $request->boolean('is_stable', true),
            'is_forced'   => $request->boolean('is_forced', false),
            'downloads'   => 0,
            'released_at' => $data['released_at'] ?? now(),
        ]);

        return redirect()->route('admin.mnemo-versions.index')
            ->with('success', 'Mnemo version uploaded successfully.');
    }

    public function show(MnemoVersion $mnemoVersion): View
    {
        return view('admin.mnemo-versions.show', compact('mnemoVersion'));
    }

    public function destroy(MnemoVersion $mnemoVersion): RedirectResponse
    {
        Storage::disk('mnemo_versions')->delete($mnemoVersion->file_path);
        $mnemoVersion->delete();

        return redirect()->route('admin.mnemo-versions.index')
            ->with('success', 'Version deleted.');
    }
}
