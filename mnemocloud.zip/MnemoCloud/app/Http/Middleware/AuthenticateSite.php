<?php

namespace App\Http\Middleware;

use App\Models\ApiLog;
use App\Models\Site;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthenticateSite
{
    public function handle(Request $request, Closure $next): Response
    {
        $siteKey = $request->header('X-Site-Key') ?? $request->query('site_key');

        $site = null;

        if ($siteKey) {
            $site = Site::where('site_key', $siteKey)->first();
        }

        if (! $site || ! $site->is_active) {
            // Log failed attempt
            ApiLog::create([
                'site_id' => null,
                'endpoint' => $request->path(),
                'method' => $request->method(),
                'ip' => $request->ip(),
                'response_code' => 401,
                'created_at' => now(),
            ]);

            return response()->json(['error' => 'Unauthorized. Invalid or missing site_key.'], 401);
        }

        $request->attributes->set('site', $site);

        $response = $next($request);

        // Log after response
        ApiLog::create([
            'site_id' => $site->id,
            'endpoint' => $request->path(),
            'method' => $request->method(),
            'ip' => $request->ip(),
            'response_code' => $response->getStatusCode(),
            'created_at' => now(),
        ]);

        return $response;
    }
}
