<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;

class CreateAdmin extends Command
{
    protected $signature = 'mnemocloud:create-admin {email} {password}';

    protected $description = 'Create or update the MnemoCloud admin user';

    public function handle(): int
    {
        $email = $this->argument('email');
        $password = $this->argument('password');

        $user = User::updateOrCreate(
            ['email' => $email],
            [
                'name'               => 'Admin',
                'email'              => $email,
                'password'           => Hash::make($password),
                'email_verified_at'  => now(),
            ]
        );

        $this->info("Admin user {$user->email} " . ($user->wasRecentlyCreated ? 'created' : 'updated') . ' successfully.');

        return self::SUCCESS;
    }
}
