@extends('layouts.admin')

@section('title', 'Site: ' . $site->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">{{ $site->name }}</h4>
    <div>
        <a href="{{ route('admin.sites.edit', $site) }}" class="btn btn-outline-secondary">Edit</a>
        <a href="{{ route('admin.sites.index') }}" class="btn btn-outline-secondary ms-2">Back</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">Site Details</div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-4">Name</dt>
                    <dd class="col-sm-8">{{ $site->name }}</dd>
                    <dt class="col-sm-4">Domain</dt>
                    <dd class="col-sm-8">{{ $site->domain }}</dd>
                    <dt class="col-sm-4">Plan</dt>
                    <dd class="col-sm-8">
                        <span class="badge bg-{{ $site->plan === 'paid' ? 'warning text-dark' : 'secondary' }}">
                            {{ ucfirst($site->plan) }}
                        </span>
                    </dd>
                    <dt class="col-sm-4">Status</dt>
                    <dd class="col-sm-8">
                        <span class="badge bg-{{ $site->is_active ? 'success' : 'danger' }}">
                            {{ $site->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </dd>
                    <dt class="col-sm-4">Last Ping</dt>
                    <dd class="col-sm-8">{{ $site->last_ping_at ? $site->last_ping_at->format('Y-m-d H:i:s') : 'Never' }}</dd>
                    <dt class="col-sm-4">Site Key</dt>
                    <dd class="col-sm-8">
                        <code class="user-select-all">{{ $site->site_key }}</code>
                    </dd>
                    <dt class="col-sm-4">Created</dt>
                    <dd class="col-sm-8">{{ $site->created_at->format('Y-m-d H:i') }}</dd>
                </dl>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">Licenses ({{ $site->licenses->count() }})</div>
            <div class="card-body p-0">
                @if($site->licenses->isEmpty())
                    <p class="text-muted p-3 mb-0">No licenses assigned.</p>
                @else
                <table class="table table-sm mb-0">
                    <thead class="table-light">
                        <tr><th>Plugin</th><th>Granted</th><th>Expires</th></tr>
                    </thead>
                    <tbody>
                        @foreach($site->licenses as $license)
                        <tr>
                            <td>{{ $license->plugin->name ?? 'Unknown' }}</td>
                            <td>{{ $license->granted_at?->format('Y-m-d') }}</td>
                            <td>{{ $license->expires_at ? $license->expires_at->format('Y-m-d') : 'Never' }}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="mt-4">
    <form action="{{ route('admin.sites.destroy', $site) }}" method="POST"
          onsubmit="return confirm('Delete this site?')">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm">Delete Site</button>
    </form>
</div>
@endsection
