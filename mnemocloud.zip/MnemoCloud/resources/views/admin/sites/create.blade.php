@extends('layouts.admin')

@section('title', 'Add Site')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Add Site</h4>
    <a href="{{ route('admin.sites.index') }}" class="btn btn-outline-secondary">Back</a>
</div>

<div class="card border-0 shadow-sm" style="max-width:600px">
    <div class="card-body">
        <form action="{{ route('admin.sites.store') }}" method="POST">
            @csrf
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                       value="{{ old('name') }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Domain</label>
                <input type="text" name="domain" class="form-control @error('domain') is-invalid @enderror"
                       value="{{ old('domain') }}" placeholder="example.com" required>
                @error('domain')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Plan</label>
                <select name="plan" class="form-select">
                    <option value="free" {{ old('plan') === 'free' ? 'selected' : '' }}>Free</option>
                    <option value="paid" {{ old('plan') === 'paid' ? 'selected' : '' }}>Paid</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Create Site</button>
        </form>
    </div>
</div>
@endsection
