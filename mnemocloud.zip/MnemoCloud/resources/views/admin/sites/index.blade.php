@extends('layouts.admin')

@section('title', 'Sites')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Sites</h4>
    <a href="{{ route('admin.sites.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Add Site
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Name</th>
                    <th>Domain</th>
                    <th>Site Key</th>
                    <th>Plan</th>
                    <th>Status</th>
                    <th>Last Ping</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse($sites as $site)
                <tr>
                    <td>{{ $site->name }}</td>
                    <td>{{ $site->domain }}</td>
                    <td><code title="{{ $site->site_key }}">{{ substr($site->site_key, 0, 16) }}…</code></td>
                    <td>
                        <span class="badge bg-{{ $site->plan === 'paid' ? 'warning text-dark' : 'secondary' }}">
                            {{ ucfirst($site->plan) }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $site->is_active ? 'success' : 'danger' }}">
                            {{ $site->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </td>
                    <td>{{ $site->last_ping_at ? $site->last_ping_at->diffForHumans() : 'Never' }}</td>
                    <td>
                        <a href="{{ route('admin.sites.show', $site) }}" class="btn btn-sm btn-outline-primary">View</a>
                        <a href="{{ route('admin.sites.edit', $site) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No sites yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $sites->links() }}</div>
@endsection
