@extends('layouts.admin')

@section('title', 'Edit Site: ' . $site->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Edit Site: {{ $site->name }}</h4>
    <a href="{{ route('admin.sites.show', $site) }}" class="btn btn-outline-secondary">Back</a>
</div>

<div class="card border-0 shadow-sm" style="max-width:600px">
    <div class="card-body">
        <form action="{{ route('admin.sites.update', $site) }}" method="POST">
            @csrf @method('PUT')
            <div class="mb-3">
                <label class="form-label">Name</label>
                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                       value="{{ old('name', $site->name) }}" required>
                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Domain</label>
                <input type="text" name="domain" class="form-control @error('domain') is-invalid @enderror"
                       value="{{ old('domain', $site->domain) }}" required>
                @error('domain')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Plan</label>
                <select name="plan" class="form-select">
                    <option value="free" {{ old('plan', $site->plan) === 'free' ? 'selected' : '' }}>Free</option>
                    <option value="paid" {{ old('plan', $site->plan) === 'paid' ? 'selected' : '' }}>Paid</option>
                </select>
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input type="hidden" name="is_active" value="0">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1" id="is_active"
                           {{ old('is_active', $site->is_active) ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_active">Active</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Save Changes</button>
        </form>
    </div>
</div>
@endsection
