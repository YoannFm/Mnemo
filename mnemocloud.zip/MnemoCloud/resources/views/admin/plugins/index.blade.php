@extends('layouts.admin')

@section('title', 'Plugins')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Plugins</h4>
    <a href="{{ route('admin.plugins.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Add Plugin
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Name</th>
                    <th>Slug</th>
                    <th>Author</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Versions</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse($plugins as $plugin)
                <tr>
                    <td>{{ $plugin->name }}</td>
                    <td><code>{{ $plugin->slug }}</code></td>
                    <td>{{ $plugin->author ?? '—' }}</td>
                    <td>
                        @if($plugin->is_free)
                            <span class="badge bg-success">Free</span>
                        @else
                            <span class="badge bg-warning text-dark">${{ number_format($plugin->price, 2) }}</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge bg-{{ $plugin->is_active ? 'success' : 'secondary' }}">
                            {{ $plugin->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </td>
                    <td>{{ $plugin->plugin_versions_count }}</td>
                    <td>
                        <a href="{{ route('admin.plugins.show', $plugin) }}" class="btn btn-sm btn-outline-primary">View</a>
                        <a href="{{ route('admin.plugins.edit', $plugin) }}" class="btn btn-sm btn-outline-secondary">Edit</a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No plugins yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $plugins->links() }}</div>
@endsection
