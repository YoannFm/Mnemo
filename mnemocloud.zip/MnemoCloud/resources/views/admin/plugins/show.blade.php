@extends('layouts.admin')

@section('title', 'Plugin: ' . $plugin->name)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">{{ $plugin->name }}</h4>
    <div>
        <a href="{{ route('admin.plugins.edit', $plugin) }}" class="btn btn-outline-secondary">Edit</a>
        <a href="{{ route('admin.plugins.index') }}" class="btn btn-outline-secondary ms-2">Back</a>
    </div>
</div>

<div class="row g-4">
    <div class="col-md-5">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">Plugin Details</div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5">Slug</dt>
                    <dd class="col-sm-7"><code>{{ $plugin->slug }}</code></dd>
                    <dt class="col-sm-5">Author</dt>
                    <dd class="col-sm-7">{{ $plugin->author ?? '—' }}</dd>
                    <dt class="col-sm-5">Type</dt>
                    <dd class="col-sm-7">
                        @if($plugin->is_free)
                            <span class="badge bg-success">Free</span>
                        @else
                            <span class="badge bg-warning text-dark">Paid – ${{ number_format($plugin->price, 2) }}</span>
                        @endif
                    </dd>
                    <dt class="col-sm-5">Status</dt>
                    <dd class="col-sm-7">
                        <span class="badge bg-{{ $plugin->is_active ? 'success' : 'secondary' }}">
                            {{ $plugin->is_active ? 'Active' : 'Inactive' }}
                        </span>
                    </dd>
                    <dt class="col-sm-5">Description</dt>
                    <dd class="col-sm-7">{{ $plugin->description ?? '—' }}</dd>
                </dl>
            </div>
        </div>

        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-light">Upload New Version</div>
            <div class="card-body">
                <form action="{{ route('admin.plugins.versions.store', $plugin) }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="mb-3">
                        <label class="form-label">Version</label>
                        <input type="text" name="version" class="form-control @error('version') is-invalid @enderror"
                               placeholder="1.0.0" required>
                        @error('version')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Changelog</label>
                        <textarea name="changelog" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">ZIP File</label>
                        <input type="file" name="file" class="form-control @error('file') is-invalid @enderror"
                               accept=".zip" required>
                        @error('file')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="mb-3">
                        <div class="form-check">
                            <input type="hidden" name="is_stable" value="0">
                            <input class="form-check-input" type="checkbox" name="is_stable" value="1" id="is_stable" checked>
                            <label class="form-check-label" for="is_stable">Stable release</label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Upload Version</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-7">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-light">Versions ({{ $plugin->pluginVersions->count() }})</div>
            <div class="card-body p-0">
                @if($plugin->pluginVersions->isEmpty())
                    <p class="text-muted p-3 mb-0">No versions uploaded yet.</p>
                @else
                <table class="table table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Version</th>
                            <th>Stable</th>
                            <th>Size</th>
                            <th>Downloads</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($plugin->pluginVersions as $ver)
                        <tr>
                            <td>{{ $ver->version }}</td>
                            <td>
                                <span class="badge bg-{{ $ver->is_stable ? 'success' : 'secondary' }}">
                                    {{ $ver->is_stable ? 'Stable' : 'Dev' }}
                                </span>
                            </td>
                            <td>{{ $ver->file_size ? number_format($ver->file_size / 1024, 1) . ' KB' : '—' }}</td>
                            <td>{{ $ver->downloads }}</td>
                            <td>{{ $ver->created_at->format('Y-m-d') }}</td>
                            <td>
                                <form action="{{ route('admin.plugins.versions.destroy', [$plugin, $ver]) }}"
                                      method="POST" onsubmit="return confirm('Delete this version?')">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">Del</button>
                                </form>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>
        </div>
    </div>
</div>

<div class="mt-4">
    <form action="{{ route('admin.plugins.destroy', $plugin) }}" method="POST"
          onsubmit="return confirm('Delete this plugin and all its versions?')">
        @csrf @method('DELETE')
        <button type="submit" class="btn btn-danger btn-sm">Delete Plugin</button>
    </form>
</div>
@endsection
