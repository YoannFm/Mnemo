@extends('layouts.admin')

@section('title', 'API Logs')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">API Logs</h4>
</div>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">
        <form method="GET" action="{{ route('admin.api-logs.index') }}" class="row g-3">
            <div class="col-md-4">
                <label class="form-label">Filter by Site</label>
                <select name="site_id" class="form-select">
                    <option value="">All Sites</option>
                    @foreach($sites as $site)
                        <option value="{{ $site->id }}" {{ request('site_id') == $site->id ? 'selected' : '' }}>
                            {{ $site->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Response Code</label>
                <select name="response_code" class="form-select">
                    <option value="">All</option>
                    <option value="200" {{ request('response_code') == '200' ? 'selected' : '' }}>200 OK</option>
                    <option value="401" {{ request('response_code') == '401' ? 'selected' : '' }}>401 Unauthorized</option>
                    <option value="403" {{ request('response_code') == '403' ? 'selected' : '' }}>403 Forbidden</option>
                    <option value="404" {{ request('response_code') == '404' ? 'selected' : '' }}>404 Not Found</option>
                    <option value="422" {{ request('response_code') == '422' ? 'selected' : '' }}>422 Unprocessable</option>
                </select>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <button type="submit" class="btn btn-primary w-100">Filter</button>
            </div>
            <div class="col-md-2 d-flex align-items-end">
                <a href="{{ route('admin.api-logs.index') }}" class="btn btn-outline-secondary w-100">Reset</a>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover table-sm mb-0">
            <thead class="table-light">
                <tr>
                    <th>Date</th>
                    <th>Site</th>
                    <th>Method</th>
                    <th>Endpoint</th>
                    <th>IP</th>
                    <th>Code</th>
                </tr>
            </thead>
            <tbody>
                @forelse($logs as $log)
                <tr>
                    <td class="text-nowrap">{{ $log->created_at?->format('Y-m-d H:i:s') }}</td>
                    <td>{{ $log->site?->name ?? '<anonymous>' }}</td>
                    <td><span class="badge bg-secondary">{{ $log->method }}</span></td>
                    <td><code>{{ $log->endpoint }}</code></td>
                    <td>{{ $log->ip }}</td>
                    <td>
                        @php
                            $code = $log->response_code;
                            $badgeClass = $code >= 500 ? 'danger' : ($code >= 400 ? 'warning text-dark' : ($code >= 200 ? 'success' : 'secondary'));
                        @endphp
                        <span class="badge bg-{{ $badgeClass }}">{{ $code }}</span>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="text-center text-muted py-4">No logs found.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $logs->links() }}</div>
@endsection
