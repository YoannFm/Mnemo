@extends('layouts.admin')

@section('title', 'Upload Mnemo Version')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Upload Mnemo Version</h4>
    <a href="{{ route('admin.mnemo-versions.index') }}" class="btn btn-outline-secondary">Back</a>
</div>

<div class="card border-0 shadow-sm" style="max-width:600px">
    <div class="card-body">
        <form action="{{ route('admin.mnemo-versions.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label class="form-label">Version</label>
                <input type="text" name="version" class="form-control @error('version') is-invalid @enderror"
                       placeholder="1.2.3" value="{{ old('version') }}" required>
                @error('version')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Changelog</label>
                <textarea name="changelog" class="form-control" rows="5"
                          placeholder="What's new in this version...">{{ old('changelog') }}</textarea>
            </div>
            <div class="mb-3">
                <label class="form-label">ZIP File</label>
                <input type="file" name="file" class="form-control @error('file') is-invalid @enderror"
                       accept=".zip" required>
                @error('file')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="form-label">Released At</label>
                <input type="date" name="released_at" class="form-control"
                       value="{{ old('released_at', date('Y-m-d')) }}">
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input type="hidden" name="is_stable" value="0">
                    <input class="form-check-input" type="checkbox" name="is_stable" value="1" id="is_stable"
                           {{ old('is_stable', '1') == '1' ? 'checked' : '' }}>
                    <label class="form-check-label" for="is_stable">Stable release</label>
                </div>
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input type="hidden" name="is_forced" value="0">
                    <input class="form-check-input" type="checkbox" name="is_forced" value="1" id="is_forced"
                           {{ old('is_forced') ? 'checked' : '' }}>
                    <label class="form-check-label text-danger" for="is_forced">
                        <strong>Force update</strong> (all sites will be forced to update)
                    </label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Upload Version</button>
        </form>
    </div>
</div>
@endsection
