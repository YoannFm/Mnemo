@extends('layouts.admin')

@section('title', 'Mnemo Versions')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Mnemo Versions</h4>
    <a href="{{ route('admin.mnemo-versions.create') }}" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Upload Version
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table table-hover mb-0">
            <thead class="table-light">
                <tr>
                    <th>Version</th>
                    <th>Stable</th>
                    <th>Forced</th>
                    <th>Size</th>
                    <th>Downloads</th>
                    <th>Released</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                @forelse($versions as $ver)
                <tr>
                    <td><strong>{{ $ver->version }}</strong></td>
                    <td>
                        <span class="badge bg-{{ $ver->is_stable ? 'success' : 'secondary' }}">
                            {{ $ver->is_stable ? 'Stable' : 'Dev' }}
                        </span>
                    </td>
                    <td>
                        @if($ver->is_forced)
                            <span class="badge bg-danger">Forced</span>
                        @else
                            <span class="text-muted">—</span>
                        @endif
                    </td>
                    <td>{{ $ver->file_size ? number_format($ver->file_size / 1024, 1) . ' KB' : '—' }}</td>
                    <td>{{ $ver->downloads }}</td>
                    <td>{{ $ver->released_at ? $ver->released_at->format('Y-m-d') : '—' }}</td>
                    <td>
                        <a href="{{ route('admin.mnemo-versions.show', $ver) }}" class="btn btn-sm btn-outline-primary">View</a>
                        <form action="{{ route('admin.mnemo-versions.destroy', $ver) }}" method="POST"
                              class="d-inline" onsubmit="return confirm('Delete this version?')">
                            @csrf @method('DELETE')
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" class="text-center text-muted py-4">No versions yet.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<div class="mt-3">{{ $versions->links() }}</div>
@endsection
