@extends('layouts.admin')

@section('title', 'Mnemo Version: ' . $mnemoVersion->version)

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="mb-0">Mnemo v{{ $mnemoVersion->version }}</h4>
    <a href="{{ route('admin.mnemo-versions.index') }}" class="btn btn-outline-secondary">Back</a>
</div>

<div class="card border-0 shadow-sm" style="max-width:700px">
    <div class="card-body">
        <dl class="row">
            <dt class="col-sm-3">Version</dt>
            <dd class="col-sm-9"><strong>{{ $mnemoVersion->version }}</strong></dd>

            <dt class="col-sm-3">Stable</dt>
            <dd class="col-sm-9">
                <span class="badge bg-{{ $mnemoVersion->is_stable ? 'success' : 'secondary' }}">
                    {{ $mnemoVersion->is_stable ? 'Yes' : 'No' }}
                </span>
            </dd>

            <dt class="col-sm-3">Forced Update</dt>
            <dd class="col-sm-9">
                <span class="badge bg-{{ $mnemoVersion->is_forced ? 'danger' : 'secondary' }}">
                    {{ $mnemoVersion->is_forced ? 'Yes – Forces all sites to update' : 'No' }}
                </span>
            </dd>

            <dt class="col-sm-3">File Size</dt>
            <dd class="col-sm-9">{{ $mnemoVersion->file_size ? number_format($mnemoVersion->file_size / 1024, 1) . ' KB' : '—' }}</dd>

            <dt class="col-sm-3">Downloads</dt>
            <dd class="col-sm-9">{{ $mnemoVersion->downloads }}</dd>

            <dt class="col-sm-3">Released At</dt>
            <dd class="col-sm-9">{{ $mnemoVersion->released_at ? $mnemoVersion->released_at->format('Y-m-d') : '—' }}</dd>

            @if($mnemoVersion->changelog)
            <dt class="col-sm-3">Changelog</dt>
            <dd class="col-sm-9">
                <pre class="bg-light p-3 rounded">{{ $mnemoVersion->changelog }}</pre>
            </dd>
            @endif
        </dl>

        <form action="{{ route('admin.mnemo-versions.destroy', $mnemoVersion) }}" method="POST"
              onsubmit="return confirm('Delete this version?')">
            @csrf @method('DELETE')
            <button type="submit" class="btn btn-danger btn-sm">Delete Version</button>
        </form>
    </div>
</div>
@endsection
