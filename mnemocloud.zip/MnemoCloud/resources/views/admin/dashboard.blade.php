@extends('layouts.admin')

@section('title', 'Dashboard')

@section('content')
<div class="row g-4 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 me-3">
                        <span class="fs-1 text-primary"><i class="bi bi-globe"></i></span>
                    </div>
                    <div>
                        <div class="fs-2 fw-bold">{{ $stats['total_sites'] }}</div>
                        <div class="text-muted">Total Sites</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 me-3">
                        <span class="fs-1 text-success"><i class="bi bi-puzzle"></i></span>
                    </div>
                    <div>
                        <div class="fs-2 fw-bold">{{ $stats['total_plugins'] }}</div>
                        <div class="text-muted">Total Plugins</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 me-3">
                        <span class="fs-1 text-warning"><i class="bi bi-arrow-up-circle"></i></span>
                    </div>
                    <div>
                        <div class="fs-2 fw-bold">{{ $stats['total_versions'] }}</div>
                        <div class="text-muted">Mnemo Versions</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 me-3">
                        <span class="fs-1 text-info"><i class="bi bi-journal-text"></i></span>
                    </div>
                    <div>
                        <div class="fs-2 fw-bold">{{ $stats['api_calls_today'] }}</div>
                        <div class="text-muted">API Calls Today</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Welcome to MnemoCloud</h5>
                <p class="text-muted mb-0">
                    Manage your Mnemo plugin distribution and updates from this admin panel.
                    Use the sidebar to navigate between sections.
                </p>
            </div>
        </div>
    </div>
</div>
@endsection
