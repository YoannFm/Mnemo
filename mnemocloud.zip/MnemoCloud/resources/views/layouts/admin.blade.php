<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'MnemoCloud Admin')</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .sidebar {
            min-height: 100vh;
            background: #212529;
            width: 240px;
            position: fixed;
            top: 0; left: 0; bottom: 0;
            z-index: 100;
            overflow-y: auto;
        }
        .sidebar .brand {
            padding: 1.5rem 1rem;
            color: #fff;
            font-size: 1.25rem;
            font-weight: 700;
            border-bottom: 1px solid #495057;
        }
        .sidebar .nav-link {
            color: #adb5bd;
            padding: .6rem 1rem;
            border-radius: 6px;
            margin: 2px 8px;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            color: #fff;
            background: #0d6efd;
        }
        .sidebar .nav-link i { margin-right: 8px; }
        .main-content {
            margin-left: 240px;
        }
        .topbar {
            background: #fff;
            border-bottom: 1px solid #dee2e6;
            padding: .75rem 1.5rem;
        }
        .content-area { padding: 1.5rem; }
    </style>
</head>
<body>

<div class="sidebar">
    <div class="brand"><i class="bi bi-cloud-fill"></i> MnemoCloud</div>
    <nav class="nav flex-column mt-3">
        <a class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}"
           href="{{ route('admin.dashboard') }}">
            <i class="bi bi-speedometer2"></i> Dashboard
        </a>
        <a class="nav-link {{ request()->routeIs('admin.sites*') ? 'active' : '' }}"
           href="{{ route('admin.sites.index') }}">
            <i class="bi bi-globe"></i> Sites
        </a>
        <a class="nav-link {{ request()->routeIs('admin.plugins*') ? 'active' : '' }}"
           href="{{ route('admin.plugins.index') }}">
            <i class="bi bi-puzzle"></i> Plugins
        </a>
        <a class="nav-link {{ request()->routeIs('admin.mnemo-versions*') ? 'active' : '' }}"
           href="{{ route('admin.mnemo-versions.index') }}">
            <i class="bi bi-arrow-up-circle"></i> Versions Mnemo
        </a>
        <a class="nav-link {{ request()->routeIs('admin.api-logs*') ? 'active' : '' }}"
           href="{{ route('admin.api-logs.index') }}">
            <i class="bi bi-journal-text"></i> Logs API
        </a>
    </nav>
</div>

<div class="main-content">
    <div class="topbar d-flex justify-content-between align-items-center">
        <h6 class="mb-0 text-muted">@yield('title', 'Dashboard')</h6>
        <div>
            <span class="me-3 text-muted small">{{ auth()->user()->email }}</span>
            <form action="{{ route('logout') }}" method="POST" class="d-inline">
                @csrf
                <button type="submit" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </button>
            </form>
        </div>
    </div>

    <div class="content-area">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif

        @yield('content')
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
@yield('scripts')
</body>
</html>
