<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        User::updateOrCreate(
            ['email' => 'admin@mnemocloud.local'],
            [
                'name' => 'Admin',
                'email' => 'admin@mnemocloud.local',
                'password' => Hash::make('changeme123'),
                'email_verified_at' => now(),
            ]
        );
    }
}
