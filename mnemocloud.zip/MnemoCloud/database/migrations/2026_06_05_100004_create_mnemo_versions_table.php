<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('mnemo_versions', function (Blueprint $table) {
            $table->id();
            $table->string('version')->unique();
            $table->text('changelog')->nullable();
            $table->string('file_path');
            $table->bigInteger('file_size')->nullable();
            $table->boolean('is_stable')->default(true);
            $table->boolean('is_forced')->default(false);
            $table->integer('downloads')->default(0);
            $table->timestamp('released_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mnemo_versions');
    }
};
