<?php

use App\Http\Controllers\Api\V1\MnemoUpdateController;
use App\Http\Controllers\Api\V1\PingController;
use App\Http\Controllers\Api\V1\PluginApiController;
use Illuminate\Support\Facades\Route;

Route::prefix('v1')->group(function () {
    // Public ping endpoint (no site auth)
    Route::post('/ping', PingController::class);

    // Authenticated endpoints
    Route::middleware('auth.site')->group(function () {
        Route::get('/plugins', [PluginApiController::class, 'index']);
        Route::get('/plugins/{slug}', [PluginApiController::class, 'show']);
        Route::get('/plugins/{slug}/download/{version}', [PluginApiController::class, 'download'])
            ->name('api.plugins.download');

        Route::get('/updates/check', [MnemoUpdateController::class, 'check']);
        Route::get('/updates/download/{version}', [MnemoUpdateController::class, 'download'])
            ->name('api.updates.download');
    });
});
