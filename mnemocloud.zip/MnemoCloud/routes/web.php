<?php

use App\Http\Controllers\Admin\ApiLogController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\MnemoVersionController;
use App\Http\Controllers\Admin\PluginController;
use App\Http\Controllers\Admin\SiteController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn() => redirect()->route('admin.dashboard'));

// Auth routes
Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::post('/logout', [LoginController::class, 'logout'])->name('logout');

// Admin routes
Route::prefix('admin')->name('admin.')->middleware('auth')->group(function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

    Route::resource('sites', SiteController::class);
    Route::resource('plugins', PluginController::class);
    Route::post('plugins/{plugin}/versions', [PluginController::class, 'storeVersion'])->name('plugins.versions.store');
    Route::delete('plugins/{plugin}/versions/{version}', [PluginController::class, 'destroyVersion'])->name('plugins.versions.destroy');

    Route::resource('mnemo-versions', MnemoVersionController::class)->except(['edit', 'update']);

    Route::get('api-logs', [ApiLogController::class, 'index'])->name('api-logs.index');
});
